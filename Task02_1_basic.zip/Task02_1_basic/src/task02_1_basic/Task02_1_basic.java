/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_1_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Task02_1_basic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      double a=156;
      double m_mg = Calculations.convertToMg(a);
      double m_t = Calculations.convertToT(a);      
      double m_g = Calculations.convertToG(a);
        System.out.println("Масса динозавра в кг.: " + a);
        System.out.println("Масса динозавра в мг.: " + m_mg);
        System.out.println("Масса динозавра в т.: " + m_t);
        System.out.println("Масса динозавра в г.: " + m_g);
    }
    
}
