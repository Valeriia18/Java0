/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_1_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Calculations {
    public static double convertToMg(double a){
     return a*1_000_000;
    }
    public static double convertToG(double a){
    return a*1000;
    }
    public static double convertToT(double a){
    return a/1000;
    }
}
