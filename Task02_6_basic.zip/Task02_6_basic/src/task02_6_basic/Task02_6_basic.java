/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_6_basic;

import java.util.Scanner;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Task02_6_basic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String a = in.nextLine();
        char[] arr = a.toCharArray();

        for (int i = arr.length - 1; i >= 0; i--) {
            System.out.printf("%s", arr[i]);
        }
        System.out.println();
    }
}
