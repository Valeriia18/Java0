/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_2_basic;

import java.util.Scanner;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class UserInput {

    public static final Scanner in = new Scanner(System.in);

    public static double Input(String msg) {
        System.out.println(msg);
        return in.nextDouble();
    }
}
