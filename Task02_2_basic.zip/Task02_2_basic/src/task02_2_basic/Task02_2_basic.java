/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_2_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Task02_2_basic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       double a = UserInput.Input("Enter a: ");
       double b = UserInput.Input("Enter b: ");
       double c = UserInput.Input("Enter c: ");
       
       boolean result = NumberLogic.compareABC(a, b, c);
       
        String msg = result ? "Yes, numbers are similar": "No, numbers are different";
        ConsolePrinter.print(msg);
    }
    
}
