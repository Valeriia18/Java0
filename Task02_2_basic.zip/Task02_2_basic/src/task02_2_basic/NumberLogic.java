/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_2_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class NumberLogic {
    public static boolean compareABC(double a, double b, double c){
        return ((a == b) & (a == c));
                          
         }
    }
   
