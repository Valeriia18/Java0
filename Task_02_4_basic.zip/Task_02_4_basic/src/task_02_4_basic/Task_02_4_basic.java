/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task_02_4_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Task_02_4_basic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a = UserInput.Input("Enter a: ");
        byte finalResult = Calculations.isIncerasingOrDecreasingNumber(a);
        switch (finalResult) {
            case 1:
                System.out.println("Возрастающая последовательность");
                break;
            case -1:
                System.out.println("Убывающая последовательность");
                break;
            case 0:
                System.out.println("Последовательность не определена");
                break;
        }
    }

}
