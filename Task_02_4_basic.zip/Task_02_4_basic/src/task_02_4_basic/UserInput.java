/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task_02_4_basic;

import java.util.Scanner;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class UserInput {

    public static final Scanner A = new Scanner(System.in);

    public static final int Input(String msg) {
        System.out.println(msg);
        return A.nextInt();
    }

}
