/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task_02_4_basic;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class ConsolePrinter {
   public static void print (String msg){
    System.out.println(msg);
   }
}
