/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task02_7;

import java.util.*;

/**
 *
 * @author Valeriia_Amialchenia
 */
public class Calculations {
//    public static int changceNumbers(int a, int b){
//    a = a + b;
//    b = a - b;
//    a = a - b;
//    
//    return new int[] {a, b};
//}

    public static List something() {
        List<Integer> list = new ArrayList<Integer>();
        int a = 3;
        int b = 2;
        a = a + b;
        b = a - b;
        a = a - b;
        list.add(a);
        list.add(b);
        return list;
    }
}
